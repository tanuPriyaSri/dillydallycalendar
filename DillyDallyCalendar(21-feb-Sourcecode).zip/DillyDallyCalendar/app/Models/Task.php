<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\User;
use App\Models\taskTiming;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;






class Task extends Model
{
     protected $table='task';
     protected $primaryKey = 'task_id';

     protected $fillable = [
        'task_id','user_id', 'title','category','task_type','description','priority','note','start_date','created_datetime','updated_datetime','is_completed'
     ];

     public $timestamps = false;

     public function taskTiming()
     {
         return $this->hasMany(TaskTiming::class, 'task_id');
     }



     public function getTodayTasks()
     {
         $today = (new \DateTime())->format('Y-m-d');
     
         return DB::table('task')
             ->leftJoin('task_timing', 'task.task_id', '=', 'task_timing.task_id')
             ->select(
                 'task.task_id',
                 'title',
                 'category',
                 'task_type',
                 'description',
                 'priority',
                 'note',
                 'start_date',
                 'reminder_time',
                 DB::raw(
                     "JSON_ARRAYAGG(
                         JSON_OBJECT(
                             'id', task_timing.id,
                             'timing', task_timing.timing,
                             'is_complete', task_timing.is_complete,
                             'duration', task_timing.duration,
                             'end_time', 
                                 CASE 
                                     WHEN task_timing.timing IS NOT NULL AND task_timing.duration IS NOT NULL THEN 
                                         DATE_ADD(
                                             STR_TO_DATE(CONCAT(task.start_date, ' ', task_timing.timing), '%Y-%m-%d %H:%i:%s'), 
                                             INTERVAL task_timing.duration SECOND
                                         )
                                     ELSE
                                         NULL
                                 END
                         )
                     ) AS task_timing"
                 )
             )
             ->whereDate('task.start_date', '=', $today)
             ->groupBy(
                 'task.task_id',
                 'title',
                 'category',
                 'task_type',
                 'description',
                 'priority',
                 'note',
                 'start_date',
                 'reminder_time'
             )
             ->get();
     }

    

     
     




   
}


