<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
// use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;



class UserDeviceToken extends Model
{
    protected $fillable = [
        'user_id','device_type', 'device_token','device_make_model','device_os_version','installed_app_version','created_datetime','updated_datetime'
     ];
}
