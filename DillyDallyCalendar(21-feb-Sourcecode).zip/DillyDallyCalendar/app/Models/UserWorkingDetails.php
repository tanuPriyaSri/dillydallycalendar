<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Factories\HasFactory;

use Laravel\Lumen\Auth\Authorizable;
// use Illuminate\Foundation\Auth\User as Authenticatable;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Tymon\JWTAuth\Contracts\JWTSubject;

class UserWorkingDetails extends Model
{
    protected $table ='user_working_details';
    //protected $primaryKey = 'user_id';
    
    protected $fillable = 
    [
        'user_id','working_days','start_time','end_time','created_datetime','updated_datetime'
    ];

    public $timestamps = false;
    
}
