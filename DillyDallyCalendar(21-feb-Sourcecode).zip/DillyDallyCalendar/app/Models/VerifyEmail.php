<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Schema;


class VerifyEmail extends Model
{
    protected $table = 'verify_email';
    protected $fillable = [
        'email_id','otp','created_datetime',
    ];
    public $timestamps = false;

    // public static function createTable()
    // {
    //     $tableName = (new self())->getTable();

    //     if (!Schema::hasTable($tableName)) {
    //         Schema::create($tableName, function ($table) {
    //             $table->id();
    //             $table->string('email_id')->unique();
    //             $table->string('otp');
    //             //$table->timestamps();
    //         });
    //     }
    // }
}
