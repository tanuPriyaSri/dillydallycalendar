<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Contracts\Auth\Factory as Auth;
use App\Models\User;

class UserAuthenticate
{
    

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {

        //return $next($request);
        
        $authKey = $request->header('Auth-Token');

        if (!$authKey) {
            return response()->json(['message' => 'Missing Auth-Token header'], 400);
        }

        
        $user = User::where('auth_key', $authKey)->first();


        if ($user != NULL && count(json_decode(json_encode($user), true)) > 0)
        {
            
            if ($user->is_blocked == 1)
            {
                $message['message'] = 'Your account has been temporarily blocked, please contact Dillydally Calender support team.';
                return response()->json($message, 403);
            }

            if ($user->is_deleted == 1)
            {
                $message['message'] = 'Your account has been temporarily deleted, please contact Dillydally Calender support team.';
                return response()->json($message, 403);
            }
            
            $userId = $user->user_id;
            $request->merge(array("current_requested_user_id" => $userId));
            
            return $next($request);
            
        }
        else
        {
            $message = '';
            return response($message, 401);
        }

       /* if ($this->auth->guard($guard)->guest()) {
            return response('Unauthorized.', 401);
        }

        return $next($request);*/
    }
}
