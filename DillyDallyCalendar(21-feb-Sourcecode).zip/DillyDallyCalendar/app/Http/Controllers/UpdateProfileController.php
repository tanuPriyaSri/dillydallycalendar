<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\VerifyEmail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;


// use Illuminate\Support\Facades\Mail;


class UpdateProfileController extends Controller
{
    public function updateProfile(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            'first_name' => 'string',
            'last_name' => 'string',
            // 'profile_image_full_url' => 'string',
            // Add more validation rules as needed
        ]);

       // dd($request->all());

        if($validator->fails())
        {
            $errorArray = json_decode($validator->errors(), true);
            $error = current($errorArray);
            $message['message'] = $error[0];
            return response()->json($message,400);
        }


                $userId = $request->current_requested_user_id;
                
                if($userId)
                {
                   // $data = [];
                    $firstname = $request->first_name;
                    $lastname = $request->last_name;
                    $profileimage = $request->profile_image_full_url;
                 
                    // dd($profileimage);
                    
                    $data = [];


                    if (!empty($firstname)) {
                        $data['first_name'] = $firstname;
                    }
                
                    if (!empty($lastname)) {
                        $data['last_name'] = $lastname;
                    }

                    if (!empty($profileimage)) {
                        $data['profile_image_full_url'] = $profileimage;
                    }


                    $data['updated_datetime'] = Date::now();

                
                    if (!empty($data)) {
                        $updateResult = User::where('user_id', $userId)->update($data);
                
                        if ($updateResult) {

                            $user = User::where('user_id', $userId)->first();
                            
                            if($user->profile_image_full_url != NULL || $user->profile_image_full_url != ""){
                                $profileFullImageUrl = url('storage/app/public/'.$user->profile_image_full_url);
                            }else{
                                $profileFullImageUrl = '';
                            }
                            
                            $resData['user_id']= $userId;
                            $resData['first_name']= $user->first_name;
                            $resData['last_name']= $user->last_name;
                            $resData['email_id']= $user->email_id;
                            $resData['profile_image_short_url'] = $user->profile_image_full_url;
                            $resData['profile_image_full_url'] = $profileFullImageUrl;
     
                          
                            return response()->json(['data'=>$resData,'message' => 'Profile updated successfully'],200);
                        } else{
                            return response()->json(['message' => 'No changes made']);
                        }
                    } else {
                        return response()->json(['message' => 'No fields provided for change']);
                    }
                    
                 
                }

                return response()->json(['error' => 'Invalid Auth Token'], 401);
    }
    
}
    

  
        
  
    
