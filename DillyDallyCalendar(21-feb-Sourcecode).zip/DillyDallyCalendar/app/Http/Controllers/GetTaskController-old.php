<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\TaskTiming;
use App\Models\User;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;


class GetTaskController extends Controller
{
     
    public function getTodayTask(Request $request)
    {

        $userId = $request->current_requested_user_id;
        $today = (new \DateTime())->format('Y-m-d');
        // dd($today);

        
        
        $usertaskTiming = DB::table('task')
                        ->leftJoin('task_timing', 'task.task_id', '=', 'task_timing.task_id')
                        ->leftJoin('users', 'task.user_id', '=', 'users.user_id')
                        ->select(
                            'task.user_id',
                            'task.task_id',
                            'task.title',
                            'task.task_type',
                            'task.priority',
                            'task.start_date',
                            'task.reminder_time',
                            'task.category',
                            'task.note',
                            'task.description',
                            'task_timing.id',
                            'task_timing.timing',
                            'task_timing.end_time',
                            'task_timing.duration',
                            'task_timing.is_complete',
                            'task.is_completed',
                            'users.timezone',
                            'users.time_offset'
                            
                        )
                        ->where('task.user_id', $userId)
                        ->whereDate('task.start_date', $today) 
                        ->groupBy(
                            'task.user_id', 'task.task_id','task.title','task.task_type','task.priority','task.start_date', 'task.reminder_time','task.category','task.note','task.description','task_timing.id', 'task_timing.is_complete', 'task.is_completed','task_timing.timing','task_timing.duration','task_timing.end_time','users.timezone','users.time_offset')
                        ->get();

        //  dd($usertaskTiming);

        $taskcount = count($usertaskTiming);
      

        $response = ['data' => ['completed_task' => [], 'ongoing_task' => [], 'missed_task' => [], 'upcoming_task' => []]];

        for ($i = 0; $i < $taskcount; $i++) {
            $task = $usertaskTiming[$i];
            $user_id = $task->user_id;
            $start_date = $task->start_date;
            $reminder_time = $task->reminder_time;
            $category = $task->category;
            $notes = $task->note;
            $description = $task->description;
            $duration = $task->duration;
            $is_complete = $task->is_complete;
            $taskId = $task->task_id;
            $task_timing_id = $task->id;
            $title = $task->title;
            $task_type= $task->task_type;
            $priority = $task->priority;

            $startTime =$task->timing;
            $endTiming =$task->end_time;

           
            $userTimezone = $task->timezone;

            // if($userTimezone == '' || $userTimezone == NULL){
            //     $userTimezone ="Asia/Kolkata";
            // }

            $gmatTime = gmdate('H:i:s');
            

            // convert gmttime to local time
            $currentTime = $this->convertUtcToLocalTime($gmatTime, $userTimezone);
            // dd( $curentTime );

            $glbStarthour = date('H', strtotime($currentTime));
            // dd($glbStarthour);
            $endHourTimestamp = strtotime($glbStarthour . ':00:00') + 3600; // Adding 3600 seconds (1 hour)
            $glbEndhour = date('H', $endHourTimestamp);
            // dd($glbEndhour);

         
            //Logic for Ongoing task
            // $is_ongoing = $startTimeStamp > $glbStarthour && $startTimeStamp < $glbEndhour;

            $is_ongoing = ($currentTime >= $startTime && $currentTime < $endTiming);

          

            //Logic for Missed Task
            $is_missed = $endTiming < $currentTime && $is_complete == 0;
        

            // Use a simpler array structure for task details
            $taskDetails = [
                'user_id' => $user_id,
                'id'=>$task_timing_id ,
                'task_id'=>$taskId,
                'title'=>$title,
                'task_type'=> $task_type,
                'priority'=>$priority,
                'start_date' => $start_date,
                'reminder_time' => $reminder_time,
                'category'=>$category,
                'note'=>$notes,
                'description'=>$description,
                'duration' => $duration,
                'is_complete' => $is_complete,
                'timing'=>$startTime,
                'end_time'=>$endTiming,
               
            ];
            
            if ($is_complete == 1)
            {
                array_push($response['data']['completed_task'], $taskDetails);
            } 
            elseif ($is_ongoing) 
            {
                array_push($response['data']['ongoing_task'], $taskDetails);
            } 
            elseif ($is_missed) 
            {
                array_push($response['data']['missed_task'], $taskDetails);
            } 
            else 
            {
                array_push($response['data']['upcoming_task'], $taskDetails);
            }
           
        }
       
            return response()->json($response);
           

    }

    public function convertUtcToLocalTime ($utcTime, $timezone) {

        // Create a DateTime object for the UTC time
        $utcDateTime = new \DateTime($utcTime, new \DateTimeZone('UTC'));
        
        // Set the desired time zone for conversion
        $localTimeZone = new \DateTimeZone($timezone); // Replace with your local time zone
        
        // Set the time zone for the DateTime object
        $utcDateTime->setTimezone($localTimeZone);
        
        // Get the local time
        $localTime = $utcDateTime->format('H:i:s');
        
        return $localTime;
        
        //echo "UTC Time: {$utcTime}\n";
        //echo "Local Time: {$localTime}\n";
        }
    





    
   
   


}








    

   

