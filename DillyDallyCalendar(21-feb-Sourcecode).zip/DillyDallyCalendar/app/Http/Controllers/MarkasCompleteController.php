<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\TaskTiming;
use App\Models\User;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;
// use Carbon\Carbon;

class MarkasCompleteController extends Controller
{
    public function markasCompleteTask(Request $request)
    {
        $userId = $request->current_requested_user_id;

        if(!$userId)
        {
            return response()->json(['error' => 'Invalid Auth Token'], 401);
        }

         $tasksModel = new Task();
         $getTaskDetails = $tasksModel->getTodayTasks();

         $taskTimingId = $request->id;

        // Update the 'is_complete' column in the 'task_timing' table
        $result = DB::table('task_timing')
                ->where('id', $taskTimingId)
                ->update(['is_complete' => 1]);

        $createdDatetime = Date::now();

       
        if($result)
        {
            DB::table('users_points_summary')->insert([
            'user_id'=>$userId,
            'type'=>3,
            'point'=>15,
            'type_id'=>$taskTimingId,
            'created_datetime'=>$createdDatetime,
            ]);
            
        }

        if($result)
            {
                return response()->json(['message'=>'Marked as Completed'],200);
            }
            else{
                return response()->json(['error'=>'Something went wrong!!'],404);
            }
      
      
    }
}
