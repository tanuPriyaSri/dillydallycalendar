<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\VerifyEmail;
//use Illuminate\Http\Response;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;



class EmailVerificationController extends Controller
{
    public function verifyEmailAddress(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'otp' => 'required',
            'email_id' => 'required|email',
        ]);

        if ($validator->fails()) {
            $errorArray = json_decode($validator->errors(), true);
            $error = current($errorArray);
            $message['message'] = $error[0];
            return response()->json($message, 400);
        }

        $verification = VerifyEmail::where('email_id',$request->email_id)
                                   ->where('otp',$request->otp)
                                   ->first();

        if($verification)
        {
            return response()->json(['message'=>'Email verified successfully'],200);
        }
        else
        {
      
        return response()->json(['message' => 'Invalid Otp'],404);
        }

    }
}
