<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\VerifyEmail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Tymon\JWTAuth\Facades\JWTAuth;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Support\Facades\Mail;



class ForgetPasswordController extends Controller
{
    public function sendforgetPasswordOtp(Request $request)
    {
        $validator = Validator::make($request->all(),
        [
            'email_id' => 'required|email:users',
        ]);

        if($validator->fails())
        {
            $errorArray = json_decode($validator->errors(), true);
            $error = current($errorArray);
            $message['message'] = $error[0];
            return response()->json($message,400);
        }

        $emailId = $request->email_id;
        $otp = rand(100000,999999);

        $user = User::where('email_id',$emailId)->first();

        if(!$user)
        {
            return response()->json(['message'=>'Email not found'],404);
        }

        $user->update(['forgot_password_otp' => $otp]);

        Mail::raw("Your OTP is: $otp", function ($message) use ($emailId) 
        {
                $message->to($emailId)->subject('Forget Password');
        });


        return response()->json(['message'=>'Password reset otp send successfully'],200);
    }

   

    // public function resetPassword(Request $request)
    // {
    //     $validator = Validator::make($request->all(),[
    //         'email_id' => 'required|email',
    //         //'password' => 'required',
    //         'new_password' => 'required|min:6',
    //         'confirm_password'=>'required|same:new_password'
    //     ]);

    //     if($validator->fails())
    //     {
    //         $errorArray = json_decode($validator->errors(),true);
    //         $error = current($errorArray);
    //         $message['message'] = $error[0];
    //         return response()->json($message,400);
    //     }
     

    //     $userId = $request->current_requested_user_id;

    //     $emailId = $request->email_id;


    //     $user = User::where('email_id', $emailId)->first();
    //     //dd($userId);

    //     if (!$userId) {
    //         return response()->json(['error' => 'User not found'], 404);
    //     }

       
    //     //Update the user password 
    //     $user->update([
    //         'password' => Hash::make($request->new_password),
    //     ]);
    
    //     return response()->json(['message' => 'Password updated successfully'], 200);
    // }

    

    
   

   
}
