<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\VerifyEmail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Tymon\JWTAuth\Facades\JWTAuth;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class UploadProfileImageController extends Controller
{
   
    public function uploadProfileImage(Request $request)
    {
        $validator = Validator::make($request->all(),
        [
            'profile_image_full_url' => 'required|image|mimes:jpeg,png,jpg',
        ]);


        if ($validator->fails()) {
            $errorArray = json_decode($validator->errors(), true);
            $error = current($errorArray);
            $message['message'] = $error[0];
            return response()->json($message, 400);
        }
        $profileImage = $request->file('profile_image_full_url');
        $profileImageUrl = null; // Default value in case no profile image is uploaded

       if ($profileImage) {
           $imageName = 'profile_images/'.gmdate('Y').'/'.gmdate('m').'/img_'.time() . '.' . $profileImage->getClientOriginalExtension();

           // Build the full path
           $fullPath = storage_path('app/public/') . $imageName;

           // Create the directory if it doesn't exist
           $directory = dirname($fullPath);

           if (!file_exists($directory)) {
               mkdir($directory, 0755, true);
           }


           $profileImage->move($directory, $imageName);
           $profileImageUrl = $imageName;//'/profile_images/' . $imageName;
           
           $staticUrl = url('storage/app/public');
           $data['profile_image_short_url'] = $profileImageUrl;
           $imageFullUrl = $staticUrl .'/'. $profileImageUrl;
           $data['profile_image_full_url']= $imageFullUrl;


           return response()->json(['data' => $data, 'message' => 'Profile image uploaded successfully'], 200);

       
       }

        return response()->json(['error' => 'Something went wrong'],401);
    }

}
