<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\VerifyEmail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Tymon\JWTAuth\Facades\JWTAuth;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;
use App\Models\UserPointSummary;

class GetPointSummaryController extends Controller
{
    public function getPointSummary(Request $request)
    {
        $userId = $request->current_requested_user_id;

        if(!$userId)
        {
            return response()->json(['message'=>'Invalid Auth Token'],404);
        }

        // $getSummary = DB::table('users_points_summary')
        //              ->where('id', $userId) // Orders the records by the id column in descending order
        //             ->get(); 

        $perPage = $request->input('per_page', 50);
         
        $getSummary = UserPointSummary::where('user_id', $userId) 
                     ->orderBy('id', 'DESC')
                     ->paginate($perPage);

                

        // $perPage = $request->input('per_page', 50); 

        return response()->json([
            'data' => $getSummary->items(),
            'pagination' => [
                'per_page' => $getSummary->perPage(), 
              
            ],
        ]);
       
    
       
    }
}
