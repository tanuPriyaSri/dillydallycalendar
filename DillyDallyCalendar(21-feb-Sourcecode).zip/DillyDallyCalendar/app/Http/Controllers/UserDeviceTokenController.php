<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\UserWorkingDetails;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Models\User;
use App\Models\userDeviceToken;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;


class UserDeviceTokenController extends Controller
{
    public function updateDeviceToken(Request $request)
    {
        
        $validator = Validator::make($request->all(),
        [
            // 'user_id'=>'required',
            'device_type'=>'required',
            'device_token'=>'required',
            'device_make_model'=>'required',
            'device_os_version'=>'required',
            'installed_app_version'=>'required',
           
        ]);

        if($validator->fails())
        {
            $errorArray = json_decode($validator->errors(),true);
            $error = current($errorArray);
            $message['message']=$error[0];
            return response()->json($message,400);

        }

        $userId = $request->current_requested_user_id;
        // dd($userId);

        if(!$userId)
        {
            return response()->json(['message' => 'Invalid Auth Token'], 401);
        }

        $user = User::find($userId);
        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }

        $timezone = $user->timezone;
        $timeOffset =  $user->time_offset;
        // dd($timezone);
        // dd($timeOffset);

       
        // $userId = $request->user_id;
        $deviceType = $request->device_type;
        $deviceToken = $request->device_token;
        $deviceMakemodel = $request->device_make_model;
        $deviceOSversion = $request->device_os_version;
        $installedAppversion = $request->installed_app_version;
        $createdAt = Date::now();

        //First Delete the record before inserting

        DB::table('users_devices')
        ->where('user_id', $userId)
        ->delete();

         // Insert the new record
         DB::table('users_devices')->insert([
            'user_id' => $userId,
            'device_type' => $deviceType,
            'device_token' => $deviceToken,
            'device_make_model' => $deviceMakemodel,
            'device_os_version' => $deviceOSversion,
            'installed_app_version' => $installedAppversion,
            'created_datetime' => $createdAt,
        ]);

        $data['user_id']=$userId;
        $data['device_type']= $deviceType;
        $data['device_token']=$deviceToken;
        $data['device_make_model']=$deviceMakemodel;
        $data['device_os_version'] = $deviceOSversion;
        $data['installed_app_version'] = $installedAppversion;
        

        return response()->json(['data'=>$data],200);
           
    
           

       
      

        
    }
}
