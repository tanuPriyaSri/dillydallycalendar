<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\VerifyEmail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Tymon\JWTAuth\Facades\JWTAuth;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;


use Illuminate\Http\Request;

class UserController extends Controller
{
    public function signUp(Request $request)
    {
        $validator = Validator::make($request->all(),
        [
            'first_name'=>'required',
            //'email_id'=>'required|email|unique|verify_email',
            'email_id' => 'required|email|unique:users',
            'password'=>'required|min:6',
        ]);

      

        if ($validator->fails()) {
            $errorArray = json_decode($validator->errors(), true);
            $error = current($errorArray);
            $message['message'] = $error[0];
            return response()->json($message, 400);
        }


        
        $firstname = $request->first_name;
        $lastname = $request->last_name;
        $emailId = $request->email_id;
        $password = $request->password;
        $usertime = $request->time_offset;
        $usertimeZone = $request->timezone;
        if($request->has('profile_image_full_url')) {
             $profileImageUrl = $request->profile_image_full_url;
        }else{
            $profileImageUrl = NULL;
        }
       

        // $profile_image_thumbnail = $request->profile_image_thumbnail;
        $createdAt = Date::now();

         //Generate JWT Token

         $jwtToken = $this->generateJwtToken($firstname, $emailId);
         

        //  $result = User::uploadProfileImage($request);

        //  $profileImageUrl = $result['profile_image_full_url'];

                    
        $user = User::create(['first_name' => $firstname,'last_name' => $lastname,'email_id' => $emailId,'password'=>Hash::make($password),'auth_key' => $jwtToken,'profile_image_full_url' => $profileImageUrl,'time_offset'=>$usertime,'timezone'=>$usertimeZone,'created_datetime'=>$createdAt
        ]);

        // dd($user);

        $user_id = $user->user_id;

        if($user->profile_image_full_url != NULL || $user->profile_image_full_url != ""){
            $profileFullImageUrl = url('storage/app/public/'.$user->profile_image_full_url);
        }else{
            $profileFullImageUrl = '';
        }
        
        $data['user_id']=$user_id;
        $data['first_name']= $firstname;
        $data['last_name']=$lastname;
        $data['email_id']=$emailId;
        $data['profile_image_short_url'] = $user->profile_image_full_url;
        $data['profile_image_full_url'] = $profileFullImageUrl;
        $data['auth_key']=$jwtToken;
       
        return response()->json(['data'=>$data],200);
    }

    //Generate JWT Token Function

    public function generateJwtToken($firstname, $emailId)
    {
        $payload =
        [
            'first_name' => $firstname,
            'email_id'=>$emailId
        ];

        $key = 'bjGeOr354e3sGfKsP2R31JH5G5j2caSVPIn5Hcar2KY6Tz3dTwYbiS7EKzBGKGQ0';
        $jwt = JWT::encode($payload,$key,'HS256');

        return $jwt;

    }

   
}
