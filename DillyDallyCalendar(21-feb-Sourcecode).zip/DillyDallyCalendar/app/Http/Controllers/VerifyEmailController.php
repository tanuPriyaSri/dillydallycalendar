<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\VerifyEmail;
use Illuminate\Support\Facades\Mail;
use App\Mail\TestEmail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\DB;
use App\Models\User;




class VerifyEmailController extends Controller
{
    public function sendTestEmail()
        {
            Mail::to('tanupriya885@gmail.com')->send(new TestEmail());

            return 'Test email sent!';
        }
    
    public function sendOtp(Request $request)
    {
        
        $validator = Validator::make($request->all(), [
            //'email_id' => 'required|email|unique:verify_email',
            'email_id' => 'required|email',
        ]);

        if ($validator->fails()) {
            $errorArray = json_decode($validator->errors(), true);
            $error = current($errorArray);
            $message['message'] = $error[0];
            return response()->json($message, 400);
        }

        //Generate random otp
        $otp = rand(100000,999999);

        //Create a new user
        /*$verify_email = VerifyEmail::create([
            'email_id' => $request->input('email_id'),
            'otp' => $otp,
            'created_datetime' => Date::now(),
        ]);*/

       

        $emailId = $request->email_id;
        $createdAt = Date::now();

        $existingUser = User::where('email_id', $emailId)->first();

        if($existingUser)
        {
            return response()->json(['message'=>'User Already Exists'],400);
        }

       

        $results = DB::statement("REPLACE INTO  verify_email (email_id, otp, created_datetime) VALUES ('".$emailId."', $otp, '".$createdAt."')");

        //Send Otp via Mail 

        Mail::raw("Your OTP is: $otp", function ($message) use ($emailId) 
        {
                $message->to($emailId)->subject('OTP Verification');
        });

        return response()->json(['message'=>'OTP sent successfully'],200);
    }

   
}
