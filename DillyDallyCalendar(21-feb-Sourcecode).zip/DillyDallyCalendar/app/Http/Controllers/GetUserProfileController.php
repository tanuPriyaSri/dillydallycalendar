<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\VerifyEmail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
// use DB;
use Illuminate\Support\Facades\DB;

class GetUserProfileController extends Controller
{
    public function getUserDetails(Request $request)
    {

        $user = $request->current_requested_user_id;

        // dd($user);

        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }

        // $getResult = User::where('user_id', $user)->get();

        $getResult = DB::table('users')
                    ->leftjoin('user_working_details', 'users.user_id', '=', 'user_working_details.user_id')
                    ->select(
                        'users.user_id',
                        'first_name',
                        'last_name',
                        'email_id',
                        'profile_image_full_url',
                        'profile_image_thumbnail',
                        'time_offset',
                        'working_days',
                        'start_time',
                        'end_time'
                    )
                    ->where('users.user_id', $user)
                    ->first();

                    if ($getResult) {
                        // Check if 'working_days' is not null before decoding
                        $workingDaysArray = $getResult->working_days ? json_decode($getResult->working_days, true) : null;
                    
                        if($getResult->profile_image_full_url != NULL || $getResult->profile_image_full_url != ""){
                            $profileImageUrl = url('storage/app/public/'.$getResult->profile_image_full_url);
                        }else{
                            $profileImageUrl = '';
                        }
                        // Create the response array
                        $responseArray = [
                            'data' => [
                                'user_id' => $getResult->user_id,
                                'first_name' => $getResult->first_name,
                                'last_name' => $getResult->last_name,
                                'email_id' => $getResult->email_id,
                                'profile_image_short_url' => $getResult->profile_image_full_url,
                                'profile_image_full_url' => $profileImageUrl,
                                // 'time_offset'=>$getResult->time_offset,
                                // 'image_full_url'=>'https://dillydallycal-api.appdevelopmentservices.in/storage/app/public/'.$getResult->profile_image_full_url,
                                'profile_image_thumbnail' => $getResult->profile_image_thumbnail,
                                'working_days' => $workingDaysArray,
                                'start_time' => $getResult->start_time,
                                'end_time' => $getResult->end_time,
                                
                                
                            ],
                           
                        ];

                        // Return the response as JSON
                        return response()->json($responseArray);
                    } else {
                       
                        return response()->json(['message' => 'User not found'], 404);
                    }
        
    }
}
