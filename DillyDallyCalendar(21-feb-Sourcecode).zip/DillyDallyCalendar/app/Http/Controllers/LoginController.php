<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\VerifyEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Tymon\JWTAuth\Facades\JWTAuth;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;




class LoginController extends Controller
{
    public function emailLogin(Request $request)
    {   
        $validator = Validator::make($request->all(),
        [
            'email_id'=>'required|email:users',
            'password'=>'required:users',
        ]);

        if($validator->fails())
        {
            $errorArray = json_decode($validator->errors(), true);
            $error = current($errorArray);
            $message['message'] = $error[0];
            return response()->json($message,400);
        }

        $emailId = $request->email_id;
        $password = $request->password;

        // select * from users where email_id = $email;

        $user = User::where('email_id',$emailId)->first();
        

        if($user){

            if(Hash::check($password, $user->password)){

                
                if($user->profile_image_full_url != NULL || $user->profile_image_full_url != ""){
                    $profileFullImageUrl = url('storage/app/public/'.$user->profile_image_full_url);
                }else{
                    $profileFullImageUrl = '';
                }

                $data['user_id'] = $user->user_id;
                $data['first_name'] = $user->first_name;
                $data['last_name'] = $user->last_name;
                $data['email_id'] = $user->email_id;
                $data['profile_image_short_url'] = $user->profile_image_full_url;
                $data['profile_image_full_url'] = $profileFullImageUrl;
                // $data['time_offset']= $user->time_offset;
                $data['auth_key'] = $user->auth_key;
               


                //return response()->json($data, 200);
                return response()->json(['data'=>$data],200);
               
            }
            
                else{
                    return response()->json(['message' => 'Please enter a valid password'], 401);
                }
            }
            
            
            else{
                return response()->json(['message'=>'Please enter a valid Email Address'], 401);
            }

    }
}
