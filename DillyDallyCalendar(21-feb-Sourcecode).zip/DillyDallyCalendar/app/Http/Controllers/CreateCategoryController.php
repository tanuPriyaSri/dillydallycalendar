<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;

class CreateCategoryController extends Controller
{
    public function createCategory(Request $request)
        {
            $validator = Validator::make($request->all(), [
              
                'category' => 'required|string',
               
            ]);
        
            if ($validator->fails()) {
                $errorArray = json_decode($validator->errors(), true);
                $error = current($errorArray);
                $message['message'] = $error[0];
                return response()->json($message, 400);
            }

            $userId = $request->current_requested_user_id;

            // dd($userId);
       
      

            if(!$userId)
            {
                return response()->json(['message'=>'Invalid Auth Token'],401);
            }
            else
            {
                
               
                $category = $request->category;
                // $createdAt = Date::now();


                $user = DB::table('user_categories')->insert([
                    'user_id'=>$userId,
                    'category' => $category,
                   
                ]);

              

                $data['user_id']=$userId;
                $data['category']=$category;
               

                if ($user)
                {
                    return response()->json(['data'=>$data,'message'=>'Category Created successfully'],200);
            

                } else {
                    return response()->json(['message' => 'Failed to insert data'], 500);
                }
            }

         }
}
