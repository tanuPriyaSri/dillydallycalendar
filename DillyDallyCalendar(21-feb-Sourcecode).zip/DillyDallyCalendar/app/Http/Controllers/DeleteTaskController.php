<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\TaskTiming;
use App\Models\User;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;

class DeleteTaskController extends Controller
{
    

    public function deleteTask(Request $request)
    {
        
        $validator = Validator::make($request->all(),
        [
            'id' => 'required|exists:task_timing,id',
        ]);

        if ($validator->fails()) {
            $errorArray = json_decode($validator->errors(), true);
            $error = current($errorArray);
            $message['message'] = $error[0];
            return response()->json($message, 400);
        }

        $userId = $request->current_requested_user_id;

        if(!$userId)
        {
            return response()->json(['error' => 'Invalid Auth Token'], 401);
        }

        $taskId = $request->task_id;
        $Id = $request->id;

        $task = Task::find($taskId);
        $task_timing = TaskTiming::find($Id);
        // dd($task_timing);

        if (!$task_timing) 
        {
            return response()->json(['error' => 'Task not found'], 404);
        }

        $deleteTask = DB::table('task_timing')
                    ->where('id', $Id)
                    ->delete();

        if($deleteTask)
        {
            return response()->json(['message'=>'Task deleted Successfully'],200);
        }
            return response()->json(['error'=>'Something went wrong!'],400);
    }

   
}
