<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\TaskTiming;
use App\Models\User;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;

class GetTaskDetailsController extends Controller
{
    public function getTaskDetails(Request $request)
    {

        $user = $request->current_requested_user_id;

        // dd($user);

        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }

        $taskId = $request->task_id;
        $today = (new \DateTime())->format('Y-m-d');

        $getResult = DB::table('task')
                    ->leftjoin('task_timing', 'task.task_id', '=', 'task_timing.task_id')
                    ->select(
                        'task.task_id',
                        'task.user_id',
                        'task.title',
                        'task.category',
                        'task.task_type',
                        'task.description',
                        'task.priority',
                        'task.note',
                        'task.start_date',
                        'task.reminder_time',
                        'task.is_completed',
                        'task_timing.timing',
                        'task_timing.duration',
                        'task_timing.end_time',
                        'task_timing.is_complete',
                    )
                    ->where('task.task_id', $taskId)
                    ->whereDate('task.start_date', $today) 
                    ->get();

                    // dd($getResult);

                    if (!$getResult->isEmpty()) {
                        // Prepare data structure for response
                        $responseData = [
                            'task_id' => $getResult[0]->task_id,
                            'user_id' => $getResult[0]->user_id,
                            'title' => $getResult[0]->title,
                            'category' => $getResult[0]->category,
                            'task_type' => $getResult[0]->task_type,
                            'priority' => $getResult[0]->priority,
                            'note' => $getResult[0]->note,
                            'description' => $getResult[0]->description,
                            'reminder_time' => $getResult[0]->reminder_time,
                            'start_date' => $getResult[0]->start_date,
                            // 'created_datetime' => $getResult[0]->created_datetime,
                            'timing' => [],
                        ];
                
                        // Loop through task timing details and add to timing array
                        foreach ($getResult as $detail) {
                            $timing = [
                                'title'=>  $getResult[0]->title,
                                'timing' => $detail->timing,
                                'duration' => $detail->duration,
                                'end_time' => $detail->end_time,
                                'is_complete'=>$detail->is_complete,
                            ];
                            $responseData['timing'][] = $timing;
                        }
                
                        // Return response
                        return response()->json(['data' => $responseData], 200);
                    } else {
                        return response()->json(['message' => 'Task details not found'], 404);
                    }
        
    }
}
