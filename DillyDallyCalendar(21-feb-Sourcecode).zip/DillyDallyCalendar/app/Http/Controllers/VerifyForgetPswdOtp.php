<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\VerifyEmail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Tymon\JWTAuth\Facades\JWTAuth;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Support\Facades\Mail;

class VerifyForgetPswdOtp extends Controller
{
    public function verifyForgetPswdOtp(Request $request)
    {
        // dd("check");
        $validator = Validator::make($request->all(),[
            'email_id' => 'required|email',
            'otp' => 'required',
        ]);

        if($validator->fails())
        {
            $errorArray = json_decode($validator->errors(),true);
            $error = current($errorArray);
            $message['message'] = $error[0];
            return response()->json($message,400);
        }

        $emailId = $request->email_id;
        $otp = $request->otp;

        $user = User::where('email_id',$emailId)->first();
       
        if(!$user)
        {
            return response()->json(['message'=>'User not found'],404);
        }

        //Check otp from stored otp

        if($user->forgot_password_otp != $otp)
        {
            return response()->json(['message'=>"invalid otp"],401);
        }

        $token = $user->auth_key;
       // dd($token);

        $data['auth_key']=$token;

        return response()->json(['data'=>$data,'message'=>'Email and Otp verified successfully'],200);

        // return response()->json(['data'=>$data],200);

    }
}
