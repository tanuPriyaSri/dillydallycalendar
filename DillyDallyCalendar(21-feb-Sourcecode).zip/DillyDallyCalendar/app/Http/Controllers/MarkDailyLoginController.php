<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\VerifyEmail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Tymon\JWTAuth\Facades\JWTAuth;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;


class MarkDailyLoginController extends Controller
{
    public function markDailyLogin(Request $request)
    {
        $validator = Validator::make($request->all(),
        [
            // 'user_id'=>'required',
            // 'date'=>'required',
        ]);

        if($validator->fails())
        {
            $errorArray = json_decode($validator->errors(),true);
            $error = current($errorArray);
            $message['message'] = $error[0];
            return response()->json($message,400);

        }

        $user = $request->current_requested_user_id;

        if(!$user)
        {
            return response()->json(['message'=>'Invalid Auth Token'],401);
        }



        $userId = $user;
        $userDate = date('Y-m-d');
        // dd($userDate);

       
        // dd($userId);
        // $userDate = $request->date;

        $dailyLogin = DB::table('users_login_summary')->insert([
            'user_id'=>$userId,
            'date'=>$userDate,
        ]);

        $data['user_id']=$userId;
        $data['date']=$userDate;

        return response()->json(['data'=>$data],200);
    }
}
