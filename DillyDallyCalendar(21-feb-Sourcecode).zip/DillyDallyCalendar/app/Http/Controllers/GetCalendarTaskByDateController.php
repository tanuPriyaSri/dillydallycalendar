<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\TaskTiming;
use App\Models\User;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;

class GetCalendarTaskByDateController extends Controller
{
    public function GetCalendarTaskByDate(Request $request)
    {

        $userId = $request->current_requested_user_id;
        // dd($user);

        if (!$userId) {
            return response()->json(['error' => 'Invalid Auth Token'], 404);
        }


        // $userId = $request->user_id;
        $userDate = $request->start_date;
        $results = DB::select('CALL get_task_details_by_user_date(?, ?)', array($userId, $userDate));

        // dd($results);


        $taskcount = count($results);
      

        $response = ['data' => ['ongoing_task' => [], 'upcoming_task' => []]];

        for ($i = 0; $i < $taskcount; $i++) 
        {
            $task = $results[$i];
            $user_id = $task->user_id;
            $start_date = $task->start_date;
            $reminder_time = $task->reminder_time;
            $category = $task->category;
            $notes = $task->note;
            $description = $task->description;
            $duration = $task->duration;
            $is_complete = $task->is_complete;
            $taskId = $task->task_id;
            $task_timing_id = $task->id;
            $title = $task->title;
            $task_type= $task->task_type;
            $priority = $task->priority;

            $startTime =$task->timing;
            $endTiming =$task->end_time;

           
            $userTimezone = $task->timezone;

            // if($userTimezone == '' || $userTimezone == NULL){
            //     $userTimezone ="Asia/Kolkata";
            // }

            $gmatTime = gmdate('H:i:s');
            

            // convert gmttime to local time
            $currentTime = $this->convertUtcToLocalTime($gmatTime, $userTimezone);
            // dd( $curentTime );

            $glbStarthour = date('H', strtotime($currentTime));
            // dd($glbStarthour);
            $endHourTimestamp = strtotime($glbStarthour . ':00:00') + 3600; // Adding 3600 seconds (1 hour)
            $glbEndhour = date('H', $endHourTimestamp);
            // dd($glbEndhour);

         
            //Logic for Ongoing task
            // $is_ongoing = $startTimeStamp > $glbStarthour && $startTimeStamp < $glbEndhour;

            $is_ongoing = ($currentTime >= $startTime && $currentTime < $endTiming);

            //for upcoming task 
            $is_upcoming = ($currentTime < $startTime);

          

            //Logic for Missed Task
            // $is_missed = $endTiming < $currentTime && $is_complete == 0;
        

            // Use a simpler array structure for task details
            $taskDetails = [
                'user_id' => $user_id,
                'id'=>$task_timing_id ,
                'task_id'=>$taskId,
                'title'=>$title,
                'task_type'=> $task_type,
                'priority'=>$priority,
                'start_date' => $start_date,
                'reminder_time' => $reminder_time,
                'category'=>$category,
                'note'=>$notes,
                'description'=>$description,
                'duration' => $duration,
                'is_complete' => $is_complete,
                'timing'=>$startTime,
                'end_time'=>$endTiming,
               
            ];
            
           
            if ($is_ongoing) 
            {
                array_push($response['data']['ongoing_task'], $taskDetails);
            } 
            elseif($is_upcoming) 
            {
                array_push($response['data']['upcoming_task'], $taskDetails);
            }
           
        }

     

        return response()->json($response);
    }
    


    public function convertUtcToLocalTime ($utcTime, $timezone) {

        // Create a DateTime object for the UTC time
        $utcDateTime = new \DateTime($utcTime, new \DateTimeZone('UTC'));
        
        // Set the desired time zone for conversion
        $localTimeZone = new \DateTimeZone($timezone); // Replace with your local time zone
        
        // Set the time zone for the DateTime object
        $utcDateTime->setTimezone($localTimeZone);
        
        // Get the local time
        $localTime = $utcDateTime->format('H:i:s');
        
        return $localTime;
        
        //echo "UTC Time: {$utcTime}\n";
        //echo "Local Time: {$localTime}\n";
        }
}
