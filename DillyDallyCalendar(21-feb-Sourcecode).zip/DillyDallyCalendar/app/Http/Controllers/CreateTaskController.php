<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;




class CreateTaskController extends Controller
{

         public function createTask(Request $request)
         {
             $validator = Validator::make($request->all(), [
                 'title' => 'required|string',
                //  'category' => 'required|string',
                 'task_type' => 'required',
                 'priority' => 'required',
                 'start_date' => 'required|date',
                 'reminder_time'=>'required',
                //  'timing'=>'required|array',
                 
                 'timing.*.timing' => 'required',
                //  'timing.*.reminder_time' => 'required',
                 
             ]);
         
             if ($validator->fails()) {
                 $errorArray = json_decode($validator->errors(), true);
                 $error = current($errorArray);
                 $message['message'] = $error[0];
                 return response()->json($message, 400);
             }
 
             $userId = $request->current_requested_user_id;
 
             // dd($userId);
        
             if(!$userId)
             {
                 return response()->json(['message'=>'Invalid Auth Token'],401);
             }
             else
             {
                 // $taskId = $request->task_id;
                 $title = $request->title;
                 $category = $request->category;
                 $taskType = $request->task_type;
                 $priority = $request->priority;
                 $note = $request->note;
                 $description = $request->description;
                 $reminderTime = $request->reminder_time;
                 $startDate = new \DateTime($request->start_date);
                 // $createdAt = $request->created_datetime
                 $createdAt = Date::now();

                //  dd($startDate);
 
 
                 $task = DB::table('task')->insertGetId([
                     
                     'user_id'=>$userId,
                     'title' => $title,
                     'category' => $category,
                     'task_type' => $taskType,
                     'priority' => $priority,
                     'note' => $note,
                     'description' => $description,
                     'start_date' => $startDate, 
                     'reminder_time'=>$reminderTime,
                     'created_datetime' => $createdAt,
 
                 ]);
 
                //  dd($task);
 
                 $data['user_id']=$userId;
                 $data['title']= $title;
                 $data['category']=$category;
                 $data['task_type']=$taskType;
                 $data['priority']=$priority;
                 $data['note'] = $note;
                 $data['description']=$description;
                 $data['reminder_time'] = $reminderTime;
                 $data['start_date']=$startDate;
                 $data['created_datetime']=$createdAt;
 
                //  dd($data);

                if (!$task) {
                    return response()->json(['message' => 'Failed to insert task data'], 500);
                }
 
                $timings = $request->timing;

                $taskTimings = []; // Initialize the array outside the loop

                foreach ($timings as $timing) {
                    $duration = $timing['duration'];
                    $timing['end_time'] = $this->calculateEndTime($startDate, $timing['timing'], $duration);

                   $task_timingId = DB::table('task_timing')->insertGetId([
                        'task_id' => $task,
                        'timing' => $timing['timing'],
                        'duration' => $timing['duration'],
                        'end_time' => $timing['end_time'],
                        
                    ]);

                    // dd($task_timingId);

                    $taskTimings[] = $timing; // Store each timing entry in the array
                }

                        
                // Prepare the response data
                $responseData = [
                    'task_id' => $task, 
                    'user_id'=> $userId,
                    'title'=>$title,
                    'category'=>$category,
                    'task_type'=>$taskType,
                    'priority'=>$priority,
                    'note'=> $note,
                    'description'=>$description,
                    'reminder_time'=>$reminderTime,
                    'start_date' => $startDate->format('Y-m-d'),
                    'created_datetime'=>$createdAt,
                    'timing' => $taskTimings,
                    // 'timings' => [
                    //     'id' => $task_timingId,  // Include the timing ID in the response
                    //     'timing' => $timing['timing'],
                    //     'duration' => $timing['duration'],
                    //     'end_time' => $timing['end_time'],
                    // ],


                ];
        
                return response()->json(['data'=>$responseData,'message'=>'Task Created successfully'],200);
            }
        
 
          }

          private function calculateEndTime($startDate, $timing, $duration)
            {
                $startTime = new \DateTime($startDate->format('Y-m-d') . ' ' . $timing);
                $endTime = clone $startTime;
                $endTime->add(new \DateInterval('PT' . $duration . 'M'));

                return $endTime->format('H:i:s');
            }


        
         
                

         


       
       
    
}
