<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\UserWorkingDetails;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Models\User;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;

class UserWorkingDetailController extends Controller
{
    //
    public function userWorkingDetails(Request $request)
    {
        $validator = Validator::make($request->all(),
        [
            'working_days' => ['required', 'array', 'in:Mon,Tue,Wed,Thu,Fri,Sat,Sun'],
            // 'working_days' => 'in:Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday',
            'start_time' => 'required',
            'end_time' => 'required'
        ]);

        if($validator->fails())
        {
            $errorArray = json_decode($validator->errors(),true);
            $error = current($errorArray);
            $message['message']=$error[0];
            return response()->json($message,400);
        }

        $userId = $request->current_requested_user_id;
       
      

        if(!$userId)
        {
            return response()->json(['message'=>'Invalid Auth Token'],401);
        }
        else
        {
            
                $workingDays = json_encode($request->working_days);
                $startTime = $request->start_time;
                $endTime = $request->end_time;
                $createdAt = Date::now();

                
                

                // Convert AM/PM time to 24-hour format
                $startTimeupdate = date('H:i', strtotime($startTime));
                $endTimeupdate = date('H:i',strtotime($endTime));

                //echo $twentyFourHourTime;  // Output: 14:30


              

                $results = DB::statement("REPLACE INTO   user_working_details (user_id, working_days, start_time,end_time,created_datetime) VALUES ('".$userId."','".$workingDays."','".$startTimeupdate."','".$endTimeupdate."','".$createdAt."')");  

                $data['user_id']= $userId;
                $data['working_days']=json_decode($workingDays,true);
               
               
                $data['start_time']=$startTimeupdate;
                $data['end_time']=$endTimeupdate;


                return response()->json(['data'=>$data,'message'=>'Data saved successfully'],200);
            
            
           
        }

    }
}