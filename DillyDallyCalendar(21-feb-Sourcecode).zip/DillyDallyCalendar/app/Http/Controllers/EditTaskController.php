<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\TaskTiming;
use App\Models\User;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Collection;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;


class EditTaskController extends Controller
{
    


    // public function editTask(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'task_id' => 'required|exists:task,task_id',
    //         'title' => 'required|string',
    //         // Add validation rules for other fields as needed
    //     ]);

    //     if ($validator->fails()) {
    //         $errorArray = $validator->errors()->toArray();
    //         $error = current($errorArray);
    //         $message['message'] = $error[0];
    //         return response()->json($message, 400);
    //     }

    //     $taskId = $request->task_id;
    //     $userId = $request->current_requested_user_id;

    //     if (!$userId) {
    //         return response()->json(['message' => 'Invalid Auth Token'], 401);
    //     }

    //     // Start a database transaction
    //     DB::beginTransaction();

    //     try {
    //         // Update the task details
    //         DB::table('task')
    //             ->where('task_id', $taskId)
    //             ->update([
    //                 'title' => $request->title,
    //                 'category' => $request->category,
    //                 'task_type' => $request->task_type,
    //                 'description' => $request->description,
    //                 'reminder_time' => $request->reminder_time,
    //                 'priority' => $request->priority,
    //                 'note' => $request->note,
    //                 'start_date' => $request->start_date,
    //             ]);

    //             // Update or create task timings
    //             $timings = $request->input('timing', []);

    //             foreach ($timings as $timing) {
    //                 $duration = $timing['duration'];
    //                 $endTime = $this->calculateEndTime($request->start_date, $timing['timing'], $duration);


    //                 // Update or create the task timing record
    //                 DB::table('task_timing')
    //                     ->updateOrInsert(
    //                         ['task_id' => $taskId, 'timing' => $timing['timing']],
    //                         ['duration' => $duration, 'end_time' => $endTime]
    //                     );
    //             }

    //             // Commit the transaction
    //             DB::commit();

    //             // Return a success response
    //             return response()->json(['message' => 'Task updated successfully'], 200);

    //             } catch (\Exception $e) {
    //                 // If an error occurs, rollback the transaction
    //                 DB::rollBack();

    //                 // Return an error response
    //                 return response()->json(['message' => 'Failed to update task'], 500);
    //             }
    // }

    public function editTask(Request $request)
{
    $validator = Validator::make($request->all(), [
        'task_id' => 'required|exists:task,task_id',
        'title' => 'required|string',
        // Add validation rules for other fields as needed
    ]);

    if ($validator->fails()) {
        $errorArray = $validator->errors()->toArray();
        $error = current($errorArray);
        $message['message'] = $error[0];
        return response()->json($message, 400);
    }

    $taskId = $request->task_id;
    $userId = $request->current_requested_user_id;

    if (!$userId) {
        return response()->json(['message' => 'Invalid Auth Token'], 401);
    }

    // Start a database transaction
    //DB::beginTransaction();

   try {
        // Update the task details
        DB::table('task')
            ->where('task_id', $taskId)
            ->update([
                'title' => $request->title,
                'category' => $request->category,
                'task_type' => $request->task_type,
                'description' => $request->description,
                'reminder_time' => $request->reminder_time,
                'priority' => $request->priority,
                'note' => $request->note,
                'start_date' => $request->start_date,
            ]);

        // Delete existing task timings
        DB::table('task_timing')
                   ->where('task_id', $taskId)
                   ->where('is_complete',0)
                   ->delete();
       

        // Insert new task timings
        $timings = $request->input('timing', []);
        
        foreach ($timings as $timing) 
        {
            
                $duration = $timing['duration'];
                $endTime = $this->calculateEndTime($request->start_date, $timing['timing'], $duration);
                $isComplete = $timing['is_complete'];
            
                // Insert the task timing record
                if($isComplete == 0)
                {
                    DB::table('task_timing')->insert([
                        'task_id' => $taskId,
                        'timing' => $timing['timing'],
                        'duration' => $duration,
                        'end_time' => $endTime
                        //'is_complete'=>$isComplete
                       
                    ]);
                }
               
            
        }

        // Commit the transaction
        //DB::commit();

        // Return a success response
        return response()->json(['message' => 'Task updated successfully'], 200);

    } 
    catch (\Exception $e) {
        // If an error occurs, rollback the transaction
       // DB::rollBack();

        // Return an error response
        return response()->json(['message' => 'Failed to update task'], 500);
    }
}


    private function calculateEndTime($startDate, $timing, $duration)
    {
        if (is_string($startDate)) {
            $startDate = new \DateTime($startDate);
        }
        $startTime = new \DateTime($startDate->format('Y-m-d') . ' ' . $timing);
        $endTime = clone $startTime;
        $endTime->add(new \DateInterval('PT' . $duration . 'M'));

        return $endTime->format('H:i:s');
    }



    
}
