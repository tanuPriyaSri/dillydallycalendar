<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Date;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Facades\Validator;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use DB;

class SearchCategoryController extends Controller
{
    public function searchCategory(Request $request)
    {
        $userId = $request->current_requested_user_id;

        if(!$userId)
        {
            return response()->json(['message' => 'Invalid Auth Token'], 401);
        }
        else
        {
            
            $category = $request->category;

          

        // dd($userId);
        $searchCategories = DB::table('user_categories')
                            ->select('category')
                            ->where('user_id',$userId)
                            ->where('category', 'like', '%' . $category . '%')
                            ->get();

        $categories = $searchCategories->pluck('category')->toArray();

        // $data['user_id']=$userId;
        // $data['category']=$searchCategories;
                            
                         
        
        return response()->json(['categories'=>$categories],200);
        }
        
    }
}
