<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Mail\TestEmail;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;


/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});


$router->get('foo', function () {
    $results = DB::select("SELECT * FROM users");
    print_r($results);die;

    return response()->json($results); // or return response()->json($results);
});

//Test Mail Route
Route::get('/send-test-email', function () {
    Mail::to('tanupriya885@gmail.com')->send(new TestEmail());

    return 'Test email sent!';
});


Route::group(['prefix' => 'v1'], function () {

    // VerifyEmailController

    Route::post('/send-otp', 'VerifyEmailController@sendOtp');

    // EmailVerificationController
    Route::post('/verify-email-address','EmailVerificationController@verifyEmailAddress');

    //UserController
    Route::post('/signup','UserController@signUp');

    

    //Login Api
    Route::post('/signin-via-email','LoginController@emailLogin');

    //Forget Password Send Otp
    Route::post('/send-forgetPassword','ForgetPasswordController@sendforgetPasswordOtp');

    //verifyForgetPswdOtp
    // Route::post('/verify-forget-pswd-otp','ForgetPasswordController@verifyForgetPswdOtp');

    Route::post('/verify-forget-pswd-otp','VerifyForgetPswdOtp@verifyForgetPswdOtp');

    Route::post('/upload-profile-image','UploadProfileImageController@uploadProfileImage');

    

    // user auth middleware
    Route::group(['middleware' => 'user_auth'], function () {

        //Reset password
        //Route::post('/reset-password','ForgetPasswordController@resetPassword');

         Route::post('/reset-password','ResetPasswordController@resetPassword');


        //Update user profile
        Route::post('/profile-update','UpdateProfileController@updateProfile');


        //User Working Details
        Route::post('/user-working-details','UserWorkingDetailController@userWorkingDetails');

        Route::post('/create-task','CreateTaskController@createTask');

        Route::post('/edit-task','EditTaskController@editTask');

        Route::post('/delete-task','DeleteTaskController@deleteTask');

        

        Route::post('/create-category','CreateCategoryController@createCategory');

        Route::get('/search-category','SearchCategoryController@searchCategory');

        Route::get('/users','GetUserProfileController@getUserDetails');

        Route::get('/get-todays-task','GetTaskController@getTodayTask');

        Route::get('/get-task-details','GetTaskDetailsController@getTaskDetails');

        Route::post('/mark-as-complete','MarkasCompleteController@markasCompleteTask');

        //UserDeviceToken
        Route::post('/update-device-token','UserDeviceTokenController@updateDeviceToken');

        Route::post('/get-calendar-task-by-date','GetCalendarTaskByDateController@GetCalendarTaskByDate');

        Route::get('/mark-daily-login','MarkDailyLoginController@markDailyLogin');

        Route::get('/get-points-summary','GetPointSummaryController@getPointSummary');

        

    });





});


$router->get('/token', function(){
    $email = 'avaneesh.verma@agicent.com';

    /*$customClaims = [];

    $payload = JWTFactory::make($customClaims);

    $token = JWTAuth::encode($payload);*/

    /*$user = User::create([
        'name' => 'avaneesh',
        'email' => 'avaneesh.verma@agicent.com',
        'password' => Hash::make('qwerty'),
    ]);*/

    $payload =  [
        'name' => 'avaneesh',
        'email' => 'avaneesh.verma@agicent.com',
        'paasword' => 'ddddd'
    ];

    $key = 'bjGeOr354e3sGfKsP2R31JH5G5j2caSVPIn5Hcar2KY6Tz3dTwYbiS7EKzBGKGQ0';
/*$payload = [
    'iss' => 'http://example.org',
    'aud' => 'http://example.com',
    'iat' => 1356999524,
    'nbf' => 1357000000
];*/

$jwt = JWT::encode($payload, $key, 'HS256');
echo $jwt;
$decoded = JWT::decode($jwt, new Key($key, 'HS256'));

print_r($decoded);die;

   
    /*try { 
        // verify the credentials and create a token for the user
        if (! $token = JWTAuth::fromUser($email)) { 
            return response()->json(['error' => 'invalid_credentials'], 401);
        } 
    } catch (JWTException $e) { 
        // something went wrong 
        return response()->json(['error' => 'could_not_create_token'], 500); 
    } */
    // if no errors are encountered we can return a JWT 
    //return response()->json(compact('token'));
});